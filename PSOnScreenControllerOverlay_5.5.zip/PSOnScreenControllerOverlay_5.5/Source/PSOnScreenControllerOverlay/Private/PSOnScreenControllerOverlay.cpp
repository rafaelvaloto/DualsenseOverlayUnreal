// Copyright Epic Games, Inc. All Rights Reserved.

#include "PSOnScreenControllerOverlay.h"

#define LOCTEXT_NAMESPACE "FPSOnScreenControllerOverlayModule"

void FPSOnScreenControllerOverlayModule::StartupModule()
{
}

void FPSOnScreenControllerOverlayModule::ShutdownModule()
{
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FPSOnScreenControllerOverlayModule, PSOnScreenControllerOverlay)